package mypractice.dataobject;

import java.io.Serializable;
import java.sql.Timestamp;

public class RequestRecord implements Serializable {

	private static final long serialVersionUID = -6367602472536867403L;
	
	public Timestamp logtime;
	public String type;
	public String url;
	public String microservice;
	public RequestRecord(Timestamp logtime, String type, String url,
			String microservice) {
		super();
		this.logtime = logtime;
		this.type = type;
		this.url = url;
		this.microservice = microservice;
	}
	public Timestamp getLogtime() {
		return logtime;
	}
	public void setLogtime(Timestamp logtime) {
		this.logtime = logtime;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getMicroservice() {
		return microservice;
	}
	public void setMicroservice(String microservice) {
		this.microservice = microservice;
	}
	@Override
	public String toString() {
		return "RequestRecord [logtime=" + logtime + ", type=" + type
				+ ", url=" + url + ", microservice=" + microservice + "]";
	}
	
}
