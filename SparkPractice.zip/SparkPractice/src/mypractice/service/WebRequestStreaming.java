package mypractice.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.KafkaUtils;

import mypractice.dataobject.RequestRecord;
import mypractice.sparkutil.SparkUtil;

public class WebRequestStreaming {

	public static void main(String[] args) throws InterruptedException {
		
		SparkConf sc = SparkUtil.createSparkConf("local[*]", "WebRequestAnalyzer");
		JavaStreamingContext ssc = new JavaStreamingContext(sc, Durations.seconds(60));
		
		Map<String, Integer> topics = new HashMap<String, Integer>();
	    topics.put("webrequests", 1);
		
		JavaPairDStream<String, String> kafkaStream = KafkaUtils.createStream(ssc, "localhost:2181","spark-streaming-consumer-group", topics);
	    kafkaStream.print();  
	 
	    
	    JavaDStream<RequestRecord> mappedStream = kafkaStream.map(tuple -> mapRecords(tuple._2));
	    
	    mappedStream.print();
	    //Take min of timestamp from mappedStream
	    //filter data for 1 minute from min(ts) to min(ts) + 60 seconds
	    //groupBy request type and aggregate count for the group of request 
	    //Write the output
	    
	    
	    ssc.start();
	    ssc.awaitTermination();
	}
	
	
	public static RequestRecord mapRecords(String Record){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sssZ");
	    
		String[] recArray = Record.split(" ");
		Date parsedDate = null;
		try {
			parsedDate = dateFormat.parse(recArray[0]);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Timestamp ts = new java.sql.Timestamp(parsedDate.getTime());
		String type = recArray[1];
		String url = recArray[2];
		String ms = recArray[3];
		
		return new RequestRecord(ts, type, url, ms);
		
	}
}
