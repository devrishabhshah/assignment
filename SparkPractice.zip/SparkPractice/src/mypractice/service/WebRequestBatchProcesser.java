package mypractice.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import mypractice.dataobject.RequestRecord;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class WebRequestBatchProcesser {

	public static void main(String[] args) throws AnalysisException {
		
		Logger.getLogger("org").setLevel(Level.OFF);
		
		SparkSession ss = SparkSession.builder()
				.appName("Web Request Processor").master("local[1]")
				.getOrCreate();		
		
		Dataset<Row> webData = ss.read().format("csv").option("header", "true")
				.load("E:\\Rishabh\\SparkDir\\WebRequestData.csv");

		Dataset<RequestRecord> webDataset = webData.map(row -> {
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sssZ");
		    
			Date parsedDate = null;
			try {
				parsedDate = dateFormat.parse(row.getString(0));
			} catch (ParseException e) {
				e.printStackTrace();
			}

			Timestamp ts = new java.sql.Timestamp(parsedDate.getTime());
			String type = row.getString(1);
			String url = row.getString(2);
			String ms = row.getString(3);
			
			return new RequestRecord(ts, type, url, ms);

			
		}, Encoders.bean(RequestRecord.class));
		
		/*
		 * Approach 1:
		 * - round of the time stamp to required number of minutes interval
		 * - group by interval, request type and aggregate count of records
		 */
		
		Dataset<Row> requestData = webDataset.withColumn(
				"roundlogtime",
				org.apache.spark.sql.functions
						.round(org.apache.spark.sql.functions.col("logtime")
								.cast("long").divide(300L)).multiply(300)
						.cast("timestamp")).drop("logtime");
		
		
		Dataset<Row> result = requestData.groupBy(org.apache.spark.sql.functions.col("roundlogtime"), org.apache.spark.sql.functions.col("type")).agg(org.apache.spark.sql.functions.count("*").alias("requestCount")).orderBy(org.apache.spark.sql.functions.col("roundlogtime").desc());
		System.out.println("Approach 1 : Rounding off Time to required interval");
		result.show(false);
		
		/*
		 * Approach 2 : Using Window function
		 */		
		System.out.println("Approach 2 : Windowing");	
		webDataset.groupBy( org.apache.spark.sql.functions.window( org.apache.spark.sql.functions.col("logtime"), "5 minutes"),  org.apache.spark.sql.functions.col("type")).agg( org.apache.spark.sql.functions.count("logtime").alias("requestCount")).orderBy("window").show(false);
	}
}
