package mypractice.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeTest {

	public static void main(String[] args) {

		String tsVal = "2018-03-12T17:26:04.000-0700";
		//-0700
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sssZ");
		//[+|-]hh:mm

		
		Date parsedDate = null;
		try {
			parsedDate = dateFormat.parse(tsVal);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Timestamp ts = new java.sql.Timestamp(parsedDate.getTime());
		
		System.out.println("TS Value : " + ts);
		
	}

}
