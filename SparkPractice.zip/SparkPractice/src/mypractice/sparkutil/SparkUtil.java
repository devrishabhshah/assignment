package mypractice.sparkutil;

import org.apache.spark.SparkConf;

public class SparkUtil {

	public static SparkConf createSparkConf(String master, String appName) {
		SparkConf sc = new SparkConf();
		sc.setMaster(master);
		sc.setAppName(appName);
		return sc;
	}
	
	

}
